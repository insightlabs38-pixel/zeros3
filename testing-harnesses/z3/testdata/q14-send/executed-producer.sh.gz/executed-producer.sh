#!/bin/bash
set -eu
export LD_LIBRARY_PATH=/workspace/work/q13-tools/lib/x86_64-linux-gnu:/workspace/work/q13-tools/usr/lib/x86_64-linux-gnu
mount --make-rprivate /
mount --bind /workspace/work/q14-probe/run /run
/workspace/work/q14-tools/sbin/zfs-fuse --no-daemon --no-kstat-mount --max-arc-size 64 --zfs-prefetch-disable --pidfile /run/q14.pid > /workspace/work/q14-probe/daemon.log 2>&1 &
daemon=$!
trap 'kill "$daemon" 2>/dev/null || true; wait "$daemon" 2>/dev/null || true' EXIT
for attempt in $(seq 1 30); do
 if /workspace/work/q14-tools/sbin/zpool list; then break; fi
 sleep 1
done
truncate -s 256M /workspace/work/q14-probe/vdev
/workspace/work/q14-tools/sbin/zpool create -f -m /workspace/work/q14-probe/mnt zeros3q14 /workspace/work/q14-probe/vdev

export PATH=/workspace/work/q14-tools/sbin:$PATH
mkdir -p /workspace/work/q14-corpus/legacy
zfs create zeros3q14/src
python3 - <<'INNER'
import random,pathlib
p=pathlib.Path('/workspace/work/q14-probe/mnt/src')
r=random.Random(1042)
(p/'data').write_bytes(r.randbytes(2<<20))
(p/'repeat').write_bytes((b'ZeroS3 native send workload '+bytes(range(128)))*8192)
INNER
for n in 0 1 2 3; do
 if [ "$n" = 1 ]; then
  python3 -c "p='/workspace/work/q14-probe/mnt/src/data'; f=open(p,'r+b'); f.seek(65536); f.write(b'changed native snapshot bytes'); f.close()"
 fi
 if [ "$n" = 2 ]; then
  head -c 65536 /workspace/work/q14-probe/mnt/src/repeat >> /workspace/work/q14-probe/mnt/src/data
 fi
 if [ "$n" = 3 ]; then
  mv /workspace/work/q14-probe/mnt/src/repeat /workspace/work/q14-probe/mnt/src/renamed
 fi
 zfs snapshot zeros3q14/src@s$n
 zfs send zeros3q14/src@s$n > /workspace/work/q14-corpus/legacy/full$n.zsend
 if [ "$n" != 0 ]; then
  prev=$((n-1))
  zfs send -i zeros3q14/src@s$prev zeros3q14/src@s$n > /workspace/work/q14-corpus/legacy/incr$n.zsend
 fi
done
zfs send zeros3q14/src@s3 > /workspace/work/q14-corpus/legacy/full3-repeat.zsend
zfs receive -u zeros3q14/restored < /workspace/work/q14-corpus/legacy/full0.zsend
for n in 1 2 3; do zfs receive -u zeros3q14/restored < /workspace/work/q14-corpus/legacy/incr$n.zsend; done
zfs mount zeros3q14/restored
diff -r /workspace/work/q14-probe/mnt/src /workspace/work/q14-probe/mnt/restored
zfs list -t snapshot
for profile in off lzjb; do
 zfs create -o compression=$profile zeros3q14/independent-$profile
 cp -a /workspace/work/q14-probe/mnt/src/. /workspace/work/q14-probe/mnt/independent-$profile/
 zfs snapshot zeros3q14/independent-$profile@s3
 zfs send zeros3q14/independent-$profile@s3 > /workspace/work/q14-corpus/legacy/independent-$profile.zsend
done
zpool destroy zeros3q14
