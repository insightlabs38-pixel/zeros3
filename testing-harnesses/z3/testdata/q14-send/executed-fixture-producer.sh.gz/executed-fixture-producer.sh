#!/bin/bash
set -eu
export LD_LIBRARY_PATH=/workspace/work/q13-tools/lib/x86_64-linux-gnu:/workspace/work/q13-tools/usr/lib/x86_64-linux-gnu
mount --make-rprivate /
mount --bind /workspace/work/q14-probe/run /run
/workspace/work/q14-tools/sbin/zfs-fuse --no-daemon --no-kstat-mount --max-arc-size 64 --zfs-prefetch-disable --pidfile /run/q14.pid > /workspace/work/q14-probe/daemon.log 2>&1 &
daemon=$!
trap 'kill "$daemon" 2>/dev/null || true; wait "$daemon" 2>/dev/null || true' EXIT
for attempt in $(seq 1 30); do
 if /workspace/work/q14-tools/sbin/zpool list; then break; fi
 sleep 1
done
truncate -s 256M /workspace/work/q14-probe/vdev
/workspace/work/q14-tools/sbin/zpool create -f -m /workspace/work/q14-probe/mnt zeros3q14 /workspace/work/q14-probe/vdev

export PATH=/workspace/work/q14-tools/sbin:$PATH
mkdir -p /workspace/work/q14-corpus/legacy
zfs create zeros3q14/tiny
printf 'native tiny fixture\n' > /workspace/work/q14-probe/mnt/tiny/file
zfs snapshot zeros3q14/tiny@s0
zfs send zeros3q14/tiny@s0 > /workspace/work/q14-corpus/tiny.zsend
zpool destroy zeros3q14
